# 棋子类
# x行数，y列数
# 从1开始到20结束
class Pointer:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    # 获取和设置方法
    def getX(self): return self.x

    def getY(self): return self.y
